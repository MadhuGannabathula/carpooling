<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "carpooling";

$conn = mysqli_connect($server, $user, $pass, $database);


?>