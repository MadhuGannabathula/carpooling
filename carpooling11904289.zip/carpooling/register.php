
<?php
include('connection.php') ;
if (isset($_POST['submit'])) {
    $username=$_POST['username'];
	$email = $_POST['email'];
	$phonenumber = $_POST['phonenumber'];
	$password1 = $_POST['password1'];
    $password2 = $_POST['password2'];
    if($password1 != $password2){
        errordisplay();
    }
    else{
        echo "entered check";
        $sql = "SELECT * FROM users WHERE Emailid='$email';";
	    $result = mysqli_query($conn, $sql);

        if ($result->num_rows > 0) {
            echo "Email already regstered please login";
            
        } else {
            echo "passed";
			$_SESSION['username'] = $username;
            $sql = "INSERT INTO users (Username, Emailid,Phonenumber, Password) VALUES ('$username', '$email',$phonenumber, '$password1');";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            }
        }
        
    }
	
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>REGISTER</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Register</h2>
	</div>
	
	<form method="post" action="">

		<div class="input-group">
			<label>Enter Username</label>
			<input type="text" name="username" value="">
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email" value="">
		</div>
		<div class="input-group">
			<label>Enter Phonenumber</label>
			<input type="number" name="phonenumber">
		</div>
		<div class="input-group">
			<label>Enter Password</label>
			<input type="password" name="password1">
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password2">
		</div>
		<div class="input-group">
			<button class="btn" name="submit">Register</button>
		</div>
		<p>
			Visited us before? <a href="login.php">Click Here!</a>
		</p>
	</form>
</body>