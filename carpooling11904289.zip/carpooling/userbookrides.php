<?php 
include('connection.php') ;
$sql = "SELECT * FROM rides2 where Bookerid = 6;";
$result = mysqli_query($conn, $sql);
?>

<?php include('menuheader.php'); ?>
<?php include('connection.php') ; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./adminrides.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <title>Document</title>
    <style>
        
    </style>
</head>
<body>
<div class="container" style = "max-width: 100%;">
<div class="row">
    <?php
    foreach($result as $r){ ?>

        <div class="col-sm-5" id="container" >
        <div class= "sub-container" style=" width:40%;">
                <div class="mini-container">
                    <h3><?php echo $r['Source']; ?></h3>
                </div>
                <div class="image-wrapper" >
                    <img src="./images/bluearrow.png" alt="To">
                </div>
                <div class="mini-container">
                    <h3><?php echo $r['Destination']; ?></h3>
                </div>
            </div>
            <div class= "sub-container"  style=" width:35%, display:flex; " >
                <p>Fare : <?php echo $r['Fare']; ?></p>
                <p>Date : <?php echo $r['Date']; ?></p>
                <p>Time : <?php echo $r['Time']; ?></p>
            </div>
            <div class= "sub-container"  style=" width:25%, display:flex; " >
                <h2><?php echo $r['Fare']; ?></h2>
                <button class = "bookbtn">Cancel</button>
            </div>
        </div>
    <?php }?>
    <div class="col-sm-5" id="container">
    <div class= "sub-container" style=" width:40%;">
            <div class="mini-container">
                <h3>Delhi</h3>
            </div>
            <div class="image-wrapper" >
                <img src="./images/bluearrow.png" alt="To">
            </div>
            <div class="mini-container">
                <h3>Jalandhar</h3>
            </div>
        </div>
        <div class= "sub-container"  style=" width:35%, display:flex; " >
            <p>Fare : 3000</p>
            <p>Dtae :today</p>
            <p>Time : 03:00</p>
        </div>
        <div class= "sub-container"  style=" width:25%, display:flex; " >
            <h2>3000</h2>
            <button class = "bookbtn">Cancel</button>
        </div>
    </div>
</div>
</div>
</body>
</html>
