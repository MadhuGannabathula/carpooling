<?php
if(isset($_POST['submit'])){

    $source=$_POST['Source'];
	$destination = $_POST['Destination'];
	$fare = $_POST['Fare'];
    $date = $_POST['Date'];
    $time = $_POST['Time'];

    $sql = "INSERT INTO rides2 (Source, Destination, Fare, Createrid, Date, Time) VALUES ('$source', '$destination', '$fare', 6 , '$date' , '$time');";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    }
}



?>