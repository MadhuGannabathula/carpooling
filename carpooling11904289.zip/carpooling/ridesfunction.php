<?php 
include('connection.php') ;
$sql = "SELECT * FROM rides2 WHERE Source='Delhi' AND Destination ='Jalandhar';";
$result = mysqli_query($conn, $sql);
?>