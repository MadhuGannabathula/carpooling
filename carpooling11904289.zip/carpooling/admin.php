<?php include('adminheader.php'); ?>
<?php include('connection.php') ; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./bootstrap.css">
    <title>Dashboard</title>
    <style>
        .row{ margin:10px;}
        #dashboard-row{
            height:400px;
            margin:10px;
        }
        .card-img-top{
            height:300px;
        }
        #dashboard-card{
            height:500px;
            align-content: center;
        }
    </style>
</head>
<body>

<div class="row" id="dashboard-row">
  <div class="col-sm-3">
    <div class="card" id="dashboard-card">
      <img class="card-img-top" src="./images/totalrides2.png" alt="Card image cap">
      <div class="card-body" id="dashboard-card">
        <h3 class="card-title" style="text-align: center;">18</h3>
        <p class="card-text" style="text-align: center;">Total Rides</p>
        <a href="./adminrides.php" class="btn btn-primary" style="margin : 20px 0px 0px 100px;">View Rides</a>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card" id="dashboard-card">
      <img class="card-img-top " src="./images/available2.png" alt="Card image cap">
      <div class="card-body">
        <h3 class="card-title" style="text-align: center;">10</h3>
        <p class="card-text" style="text-align: center;">Available Rides</p>
        <a href="./adminavailable.php" class="btn btn-primary" style="margin : 20px 0px 0px 100px;">View Rides</a>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card" id="dashboard-card">
      <img class="card-img-top" src="./images/book2.jpg" alt="Card image cap">
      <div class="card-body">
        <h3 class="card-title" style="text-align:center;">5</h3>
        <p class="card-text" style="text-align: center;">Booked Rides</p>
        <a href="./adminbook.php" class="btn btn-primary" style="margin : 20px 0px 0px 100px;">View Rides</a>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card" id="dashboard-card">
      <img class="card-img-top" src="./images/cancelled.png" alt="Card image cap">
      <div class="card-body" id="dashboard-card">
      <h3 class="card-title" style="text-align:center;">3</h3>
        <p class="card-text" style="text-align: center;">Cancelled Rides</p>
        <a href="./admincancel.php" class="btn btn-primary" style="margin : 20px 0px 0px 100px;">View Rides</a>
      </div>
    </div>
  </div>
  <div class="col-sm-3" style="margin-top : 10px ;">
    <div class="card" id="dashboard-card">
      <img class="card-img-top" src="./images/empicon1.webp" alt="Card image cap">
      <div class="card-body" id="dashboard-card">
        <h3 class="card-title" style="text-align:center;">5</h3>
        <p class="card-text" style="text-align: center;">Total Users</p>
        <a href="./adminusers.php" class="btn btn-primary" style="margin : 20px 0px 0px 100px;">View Users</a>
      </div>
    </div>
  </div>
  <div class="col-sm-3" style="margin-top : 10px ;">
    <div class="card" id="dashboard-card">
      <img class="card-img-top" src="./images/profile.png" alt="Card image cap">
      <div class="card-body" id="dashboard-card">
        <h3 class="card-title" style="text-align:center;">  </h3>
        <br>
        <p class="card-text" style="text-align: center;">Profile</p>
        <a href="/admin/employees" class="btn btn-primary" style="margin : 30px 0px 0px 50px;">Profile</a>
        <a href="/admin/employees/create" class="btn btn-primary" style="margin : 30px 0px 0px 50px;">Logout</a>
      </div>
    </div>
  </div>
</div>
    
</body>
</html>